package main.java.uia.com.contabilidad.clientes;

public interface IInfoUIA {
   public void setType(String tipo);
   public String getType();
}
