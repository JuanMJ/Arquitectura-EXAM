package main.java.uia.com.contabilidad.clientes;

import java.util.ArrayList;
import java.util.List;



public class ListaCuentas 
{
	private List<Cliente> items;

	public ListaCuentas() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}


